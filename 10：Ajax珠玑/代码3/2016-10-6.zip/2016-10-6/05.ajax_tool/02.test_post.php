<?php 

	echo $_POST['friend'];
 ?>