<?php 
	// 获取get提交的数据
	echo $_GET['skill'];
 ?>