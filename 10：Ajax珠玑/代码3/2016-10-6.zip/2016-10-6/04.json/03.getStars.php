<?php 
	// 读取并返回
	echo file_get_contents('info/stars.json');
 ?>