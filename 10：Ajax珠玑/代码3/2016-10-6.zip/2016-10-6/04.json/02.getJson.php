<?php 
	
	// 读取json文件 并返回即可
	echo  file_get_contents('info/cartoonPerson.json');

 ?>