<?php 
		// 获取 数据 php中 使用 .来拼接字符串
		echo  $_GET['name'].'你好吗';
 ?>