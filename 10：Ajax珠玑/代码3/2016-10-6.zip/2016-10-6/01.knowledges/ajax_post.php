<?php 
	// 获取 post的数据
	echo '你'.$_POST['age'].'岁了';
 ?>